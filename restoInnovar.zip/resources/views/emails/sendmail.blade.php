<!DOCTYPE html>
<html>
<head>
    <title>contact </title>
</head>
<body>
    <h1> <strong> from  </strong> {{ $details['title'] }}</h1>
    <h1> <strong> email  </strong> {{ $details['email'] }}</h1>
    
    <br>
    <p>Le msg</p>
    <p>{{ $details['body'] }}</p>
   
    <p>Thank you</p>
</body>
</html>